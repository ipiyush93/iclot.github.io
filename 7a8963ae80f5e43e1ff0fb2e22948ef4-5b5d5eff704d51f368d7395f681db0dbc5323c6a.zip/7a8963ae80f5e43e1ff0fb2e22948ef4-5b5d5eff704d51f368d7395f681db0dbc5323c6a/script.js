<script>
  // ✅ Function to update the red cart count badge in the header
  function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const totalItems = cart.reduce((sum, item) => sum + item.qty, 0);
    const cartCount = document.getElementById('cart-count');
    if (cartCount) {
      cartCount.textContent = totalItems;
    }
  }

  // ✅ Function to handle "Add to Cart" logic
  function addToCart(id, name, price, image) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    const existingItem = cart.find(item => item.id === id);
    if (existingItem) {
      existingItem.qty += 1;
    } else {
      cart.push({ id, name, price, image, qty: 1 });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    alert(`${name} added to cart!`);
    updateCartCount(); // 🟢 Update cart count badge
  }

  // ✅ Call this when page loads to show cart count correctly
  document.addEventListener('DOMContentLoaded', updateCartCount);
</script>


